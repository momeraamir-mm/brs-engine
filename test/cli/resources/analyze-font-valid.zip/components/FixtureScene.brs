sub init() as void
    ' A comment mentioning font:NotARealFontInAComment must NOT trip the rule.
    lbl = m.top.findNode("dynamic")
    if lbl <> invalid then lbl.font = "font:MediumSystemFont"
end sub
