sub init()
    ' never a callFunc across the thread boundary
    m.top.functionName = "run"
end sub

sub run()
    print "running"
end sub
