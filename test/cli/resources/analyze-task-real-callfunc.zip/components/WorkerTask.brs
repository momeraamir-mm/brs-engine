sub init()
    m.top.functionName = "run"
end sub

sub run()
    m.top.callFunc("doSomething")
end sub
