sub Main(args as dynamic) as void
    screen = CreateObject("roSGScreen")
    screen.CreateScene("MainScene")
    screen.show()
end sub
